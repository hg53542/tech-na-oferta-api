# Tech na Oferta — base de integração Mercado Livre

Projeto inicial para deploy na Vercel. **Não é uma integração pronta para produção**.

## Publicação
1. Crie um repositório privado no GitHub e envie os arquivos desta pasta.
2. Na Vercel, importe o repositório e faça Deploy.
3. Copie o domínio HTTPS real atribuído pela Vercel.
4. URL de redirect: `https://DOMINIO-REAL/api/auth/mercadolivre/callback`.
5. URL de notificações: `https://DOMINIO-REAL/api/mercadolivre/notifications` **somente após implementar e testar o processamento seguro**. Por enquanto, desmarque os tópicos no Mercado Livre.

## Antes de usar OAuth
Implementar início de login com state aleatório vinculado à sessão, PKCE quando habilitado, validação do state, troca de code por token no backend, armazenamento criptografado de tokens, rotação e renovação, logs sem segredos, controles de acesso, rate limiting e testes. O callback atual retorna 501 e não troca tokens.

## Antes de habilitar notificações
Implementar verificação de autenticidade apropriada, fila persistente, idempotência, reconsulta autenticada à API, auditoria e resposta rápida. O endpoint atual retorna 503 para não fingir processamento.

Não publique Client Secret ou tokens no repositório. Configure segredos somente no painel de variáveis de ambiente do provedor.
