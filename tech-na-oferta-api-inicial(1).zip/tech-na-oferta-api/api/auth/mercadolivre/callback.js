export default function handler(req,res){
  res.setHeader('Cache-Control','no-store');
  // Never expose the OAuth authorization code in the browser or logs.
  if(req.query?.error) return res.status(400).send('Autorizacao recusada.');
  if(!req.query?.code || !req.query?.state) return res.status(400).send('Resposta OAuth incompleta.');
  return res.status(501).send('Callback recebido. Troca segura de tokens ainda nao configurada; nao use em producao.');
}
