export default async function handler(req,res){
  if(req.method!=='POST') {res.setHeader('Allow','POST');return res.status(405).end();}
  // This endpoint intentionally does not process untrusted notifications until
  // authenticated verification, durable queueing, and idempotency are configured.
  return res.status(503).json({error:'notification processing not enabled'});
}
