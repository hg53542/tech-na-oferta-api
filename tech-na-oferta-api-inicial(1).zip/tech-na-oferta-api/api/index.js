export default function handler(req,res){res.status(200).json({app:'Tech na Oferta',status:'online',mercadolivre:'aguardando configuracao OAuth'});}
